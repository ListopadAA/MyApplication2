package com.example.myapplication.feature.profile

import androidx.fragment.app.Fragment

class ProfileFragment: Fragment() {
    // todo

}
