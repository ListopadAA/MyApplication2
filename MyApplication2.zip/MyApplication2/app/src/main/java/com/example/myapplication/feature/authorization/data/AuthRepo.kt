package com.example.myapplication.feature.authorization.data

class AuthRepo {

}
