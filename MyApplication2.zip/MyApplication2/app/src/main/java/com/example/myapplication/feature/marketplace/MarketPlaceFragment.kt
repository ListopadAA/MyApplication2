package com.example.myapplication.feature.marketplace

import androidx.fragment.app.Fragment

class MarketPlaceFragment: Fragment() {
    // todo

}