package com.example.myapplication.feature.cases

import androidx.fragment.app.Fragment

class CasesFragment: Fragment() {
    // todo
}
