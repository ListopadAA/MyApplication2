package com.example.myapplication.feature.authorization.presentation.login

class LoginViewModel {

}
